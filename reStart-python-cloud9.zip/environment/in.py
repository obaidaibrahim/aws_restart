name =input("Enter you name ")
age=input("Enter you age ")

print(name,age)

