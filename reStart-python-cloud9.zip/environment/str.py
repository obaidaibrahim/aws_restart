value=10
print(str(value)+ "  seally")

print(type(value))

