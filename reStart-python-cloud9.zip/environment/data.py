name=["obaida","ahmed","ali"]
print(type(name))

last=("khalil","mohammed","yahia")
print(type(last))

age ={
    "obaida" : 34,
    "ali": 8,
    "yahia": 88,
}
print(age)
